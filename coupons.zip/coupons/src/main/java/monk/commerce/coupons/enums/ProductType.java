package monk.commerce.coupons.enums;

public enum ProductType {

    Household_Appliances,
    Women_Clothing,
    Men_Clothing,
    Kids_Clothing,
    Electronics,
    Toys

}
