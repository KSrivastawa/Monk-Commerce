package monk.commerce.coupons.enums;

public enum CouponType {

    CART_WISE,
    PRODUCT_WISE,
    BxGy

}
